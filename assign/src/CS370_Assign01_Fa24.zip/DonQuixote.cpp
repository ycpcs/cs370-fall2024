// CS370 Assignment 1 - Don Quixote
// Fall 2024

#include <stdio.h>
#include <vector>
#include "../common/vgl.h"
#include "../common/utils.h"
#include "../common/vmath.h"

using namespace vmath;
using namespace std;

#define NUM_SUN 361

// Vertex array and buffer names
enum VAO_IDs {Square, Triangle, Sun, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, NormBuffer, TexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {SkyBlue, GrassGreen, HouseBrown, RoofRed, FanBlue, SunYellow, NumColorBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];

// Number of vertices in each object
GLint numVertices[NumVAOs];

// Number of component coordinates
GLint posCoords = 2;
GLint colCoords = 4;

// Shader variables
// Shader program reference
GLuint trans_program;
// Shader component references
GLuint trans_vPos;
GLuint trans_vCol;
GLuint trans_model_mat_loc;
// Shader source files
const char *trans_vertex_shader = "../trans.vert";
const char *trans_frag_shader = "../trans.frag";

// Global state
mat4 model_matrix;
GLboolean anim = false;
GLfloat fan_angle = 0.0;
GLdouble elTime = 0.0;
GLdouble rpm = 10.0;
GLint dir = 1;

void display( );
void render_scene( );
void build_geometry( );
void build_square(GLuint obj);
void build_triangle(GLuint obj);
void build_sun(GLuint obj);
void draw_color_object(GLuint obj, GLuint color);
void draw_color_fan_object(GLuint obj, GLuint color);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Don Quixote 2024");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // TODO: Register callbacks

    // Get initial time
    elTime = glfwGetTime();

	// Create geometry buffers
    build_geometry();
    
    // Load shaders and associate shader variables
	ShaderInfo trans_shaders[] = { {GL_VERTEX_SHADER, trans_vertex_shader},{GL_FRAGMENT_SHADER, trans_frag_shader},{GL_NONE, NULL} };
	trans_program = LoadShaders(trans_shaders);
	trans_vPos = glGetAttribLocation(trans_program, "vPosition");
    trans_vCol = glGetAttribLocation(trans_program, "vColor");
    trans_model_mat_loc = glGetUniformLocation(trans_program, "model_matrix");

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        //  TODO: Update angle based on time for fixed rpm when animating

        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
	// Clear window
	glClear(GL_COLOR_BUFFER_BIT);

    // Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene( ) {
    model_matrix = mat4().identity();

    // TODO: Declare transformation matrices

    // TODO: Draw sky

    // TODO: Draw grass

    // TODO: Draw house

    // TODO: Draw roof

    // TODO: Draw fan

    // TODO: Draw sun using draw_color_fan_object

}

void build_geometry( )
{
    // Generate vertex arrays
	glGenVertexArrays(NumVAOs, VAOs);

    // Generate color buffers
    glGenBuffers(NumColorBuffers, ColorBuffers);

    // Build squares
    build_square(Square);

    // Build triangles
    build_triangle(Triangle);

    // Build sun
    build_sun(Sun);
}

void build_square(GLuint obj) {
    vector<vec2> vertices;
    vector<ivec3> indices;
    vector<vec4> blue_grad, green_grad, brown;

    // Bind square
    glBindVertexArray(VAOs[obj]);

    // Define square vertices
    vertices = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
            { 1.0f,-1.0f},
    };

    // TODO: Define square face indices (ensure proper orientation)
    indices = {

    };
    int numFaces = indices.size();

    // TODO: Define blue sky color
    blue_grad = {

    };

    // TODO: Define green grass color
    green_grad = {

    };

    // TODO: Define brown house color
    brown = {

    };

    // TODO: Create object vertices and colors from faces

    // Set numVertices as total number of INDICES
    numVertices[obj] = 3*numFaces;

    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj

    // TODO: Bind and load color buffers

}

void build_triangle(GLuint obj) {
    vector<vec2> vertices;
    vector<ivec3> indices;
    vector<vec4> red, blue_grad;

    // Bind vertex array for obj
    glBindVertexArray(VAOs[obj]);

    // Define triangle vertices
    vertices = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
    };

    // TODO: Define triangle indices (ensure proper orientation)
    indices = {

    };
    int numFaces = indices.size();

    // TODO: Define red roof color
    red = {

    };

    // TODO: Define blue fan color
    blue_grad = {

    };

    // TODO: Create object vertices and colors from faces

    // Set numVertices as total number of INDICES (3*number of faces)
    numVertices[obj] = 3*numFaces;

    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj

    // TODO: Bind and load color buffer

}

void build_sun(GLuint obj) {
    vector<vec2> vertices;
    vector<ivec3> indices;
    vector<vec4> yellow_grad;

    // Bind vertex array for obj
    glBindVertexArray(VAOs[obj]);

    // TODO: Define sun vertices and colors for triangle fan

    // TODO: Set numVertices for sun

    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj

    // TODO: Bind and load color buffer

}

void draw_color_object(GLuint obj, GLuint color) {
    // Select shader program
    glUseProgram(trans_program);

    // Pass model matrix to shader
    glUniformMatrix4fv(trans_model_mat_loc, 1, GL_FALSE, model_matrix);

    // Bind vertex array
    glBindVertexArray(VAOs[obj]);

    // Bind position object buffer and set attributes
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

    // Bind color buffer and set attributes
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[color]);
    glVertexAttribPointer(trans_vCol, colCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vCol);

    // Draw geometry
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);
}

void draw_color_fan_object(GLuint obj, GLuint color) {
    // Select shader program
    glUseProgram(trans_program);

    // Pass model matrix to shader
    glUniformMatrix4fv(trans_model_mat_loc, 1, GL_FALSE, model_matrix);

    // Bind vertex array
    glBindVertexArray(VAOs[obj]);

    // Bind position object buffer and set attributes
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(trans_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vPos);

    // Bind color buffer and set attributes
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[color]);
    glVertexAttribPointer(trans_vCol, colCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(trans_vCol);

    // Draw geometry
    glDrawArrays(GL_TRIANGLE_FAN, 0, numVertices[obj]);
}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // Esc closes window
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // TODO: Start/Stop animation with spacebar

}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){
    // TODO: Flip spin direction with mouse click

}

